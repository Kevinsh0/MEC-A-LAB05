/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Kevin
 */
public class Departamento {
     private String Nombre;
    private int NoExports;

    public Departamento(String nombre, int exports) {
        this.Nombre = nombre;
        this.NoExports = exports;
    }
}
